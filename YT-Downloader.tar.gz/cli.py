from main import YTDownloader

def main():
    url = input("Pega la URL: ")
    
    app = YTDownloader()
    app.download_video(url)

if __name__ == "__main__":
    main()