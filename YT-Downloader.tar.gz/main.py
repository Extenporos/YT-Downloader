
from yt_dlp import YoutubeDL
from urllib.parse import urlparse

class YTDownloader:
    def valid_n_get_url(self, url: str):
        if not isinstance(url, str) or not url.strip():
            print("Error: No URL provided.")
            return None

        url = url.strip()

        if not url.startswith(("http://", "https://")):
            url = "https://" + url

        parsed = urlparse(url)
        domain = parsed.netloc.lower()

        if not domain or "." not in domain:
            print("Invalid URL.")
            return

        if any(x in domain for x in ["youtube.com", "youtu.be"]):
            return url
        else:
            print("No supported site.")
            return 

    def download_video(self, url: str):
        valid_url = self.valid_n_get_url(url)
        if not valid_url:
            return
        
        ydl_opts = {
            'format': 'best',
            'outtmpl': '%(title)s.%(ext)s',
            'noplaylist': True
        }

        with YoutubeDL({ydl_opts}) as ydl:
            ydl.download([valid_url])